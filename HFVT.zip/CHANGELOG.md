# 1.0.3 Patch Notes
- Updated for SOTS
- Added alternate primary: Permeate
- - Revitalization of the unused melee primary

# 1.0.1 Patch Notes
- Added config versioning.
- Buffed Drown Fourth Hit Damage slightly.